import React from "react";
import { Link, NavLink } from "react-router-dom";

const navItems = [
  { to: "/", label: "Home" },
  { to: "/consulting", label: "Consulting" },
  { to: "/training", label: "Training" },
  { to: "/certifications", label: "Certifications" },
  { to: "/partners", label: "Partners" },
  { to: "/clients", label: "Clients" },
  { to: "/blog", label: "Blog / Resources" },
  { to: "/about", label: "About Us" },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-800 bg-slate-950/80 backdrop-blur">
      <nav className="section-container flex items-center justify-between py-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-sky-400 flex items-center justify-center font-bold text-slate-950">
            CAI
          </div>
          <div className="flex flex-col leading-tight">
            <span className="font-semibold text-sm md:text-base">Cloud AI Solution</span>
            <span className="text-xs text-slate-400">@cloudaisolution</span>
          </div>
        </Link>

        <div className="hidden md:flex items-center gap-4 text-sm">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                [
                  "px-2 py-1 rounded-md transition-colors",
                  isActive
                    ? "text-cyan-300"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/70",
                ].join(" ")
              }
            >
              {item.label}
            </NavLink>
          ))}
        </div>
      </nav>
    </header>
  );
}

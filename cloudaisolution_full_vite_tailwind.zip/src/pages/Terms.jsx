import React from "react";

export default function Terms() {
  return (
    <div className="section-container max-w-3xl">
      <h2 className="text-2xl font-semibold text-slate-50 mb-3">Terms & Conditions</h2>
      <p className="text-sm text-slate-300">
        This is a placeholder terms & conditions page. Replace it with your
        own terms before publishing the website.
      </p>
    </div>
  );
}

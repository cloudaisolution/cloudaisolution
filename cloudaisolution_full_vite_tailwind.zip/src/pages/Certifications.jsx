import React from "react";
import { Link } from "react-router-dom";

const certificationCategories = [
  {
    name: "Cloud Certifications",
    description: "Azure, AWS, and multi‑cloud tracks from fundamentals to architect level.",
    items: [
      { id: "azure-cloud-architect", title: "Azure Cloud Architect Track" },
    ],
  },
  {
    name: "AI & Data",
    description: "AI engineering, data engineering, and analytics programs.",
    items: [
      { id: "ai-engineer", title: "Applied AI Engineer Track" },
    ],
  },
  {
    name: "DevOps & Automation",
    description: "DevOps, SRE, containers, Kubernetes, and platform engineering.",
    items: [
      { id: "devops-engineer", title: "DevOps & SRE Engineer Track" },
    ],
  },
];

export default function Certifications() {
  return (
    <div className="section-container">
      <h2 className="text-2xl md:text-3xl font-semibold text-slate-50 mb-3">
        Certifications
      </h2>
      <p className="text-sm text-slate-300 max-w-2xl mb-6">
        This section mirrors a “Categories” page but renamed to{" "}
        <span className="font-semibold text-slate-100">Certifications</span>. Each
        card represents a category, and every item opens a detailed page with
        syllabus download and enrollment form.
      </p>

      <div className="grid gap-5 md:grid-cols-3 text-sm">
        {certificationCategories.map((cat) => (
          <section
            key={cat.name}
            className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4"
          >
            <h3 className="font-semibold text-slate-50 mb-1">{cat.name}</h3>
            <p className="text-xs text-slate-300 mb-3">{cat.description}</p>
            <ul className="space-y-1 text-xs">
              {cat.items.map((item) => (
                <li key={item.id}>
                  <Link
                    to={`/certifications/${item.id}`}
                    className="text-cyan-300 hover:text-cyan-200"
                  >
                    {item.title} →
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
}

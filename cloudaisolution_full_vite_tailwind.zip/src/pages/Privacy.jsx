import React from "react";

export default function Privacy() {
  return (
    <div className="section-container max-w-3xl">
      <h2 className="text-2xl font-semibold text-slate-50 mb-3">Privacy Policy</h2>
      <p className="text-sm text-slate-300">
        This is a placeholder privacy policy page. Add your own policy text
        here once the website is ready to go live.
      </p>
    </div>
  );
}
